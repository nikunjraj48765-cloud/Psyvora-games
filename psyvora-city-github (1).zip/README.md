# Psyvora City

A free 3D wellness city that runs in the browser. Walk, ride and fly around, try breathing and meditation, journal your mood and learn about well-being. Single-player, no accounts: progress is saved in the browser.

It is a static site (one HTML file plus a few small scripts). There is no build step and no server code.

## Run locally
```bash
npm start          # or: cd site && python3 -m http.server 8080
```
Open http://localhost:8080. (The 3D engine and fonts load from CDNs, so you need internet.)

## Deploy to GitHub Pages
1. Push this repo to GitHub (branch `main`).
2. **Settings → Pages → Build and deployment → Source: GitHub Actions.**
3. Optional: **Settings → Secrets and variables → Actions → Variables**, add any of:

| Variable | Purpose |
|---|---|
| `SITE_URL` | Public address, e.g. `https://psyvora.com` (defaults to the github.io address) |
| `SUPPORT_EMAIL` | Shown on the support page; receives feedback if no form endpoint is set |
| `FEEDBACK_ENDPOINT` | Any form backend accepting JSON POSTs (Formspree, Basin...) |
| `PLAUSIBLE_DOMAIN` | Turns on anonymous analytics, only after a visitor opts in |
| `ERROR_ENDPOINT` | Receives anonymous error reports |
| `SUPABASE_URL`, `SUPABASE_ANON_KEY` | Lets the Therapist Directory and Summit Hall read your `therapists` and `workshops` tables (public read RLS needed). The anon key is public by design; never add a service_role key. |

4. Push to `main`; the workflow builds and publishes. Your site is at `https://<user>.github.io/<repo>/`.

GitHub Pages ignores the security header files. For full headers (CSP, HSTS...) deploy the `site/` folder on **Netlify** (`_headers`) or **Vercel** (`vercel.json`) instead. Both can deploy straight from this repo with `site` as the publish directory.

## Before a public launch
- Fill `[Company legal name]`, `[address]`, `[Jurisdiction]` in `site/privacy.html`, `terms.html`, `disclaimer.html` and get them reviewed by a lawyer.
- Replace `site/og-image.png` with branded artwork.
- Run `PsyQA.run()` in the browser console, play through on desktop and mobile, and run Lighthouse on the live URL.
- Add a license that suits you (none is included).

More detail: [`docs/LAUNCH.md`](docs/LAUNCH.md).

## Layout
```
site/            the website (index.html = the game, launch.js, sw.js, legal and error pages, SEO files)
.github/         GitHub Pages deploy workflow
docs/LAUNCH.md   launch notes, security and QA checklist
```

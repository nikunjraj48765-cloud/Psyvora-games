#!/bin/sh
# Generates config.js from environment variables (Netlify/Vercel build command: sh build.sh)
SITE="${SITE_URL:-https://YOUR-DOMAIN}"
cat > config.js <<JS
window.PSY_CONFIG={siteUrl:"$SITE",supportEmail:"${SUPPORT_EMAIL:-support@YOUR-DOMAIN}",version:"${APP_VERSION:-1.0.0-beta}",plausibleDomain:"${PLAUSIBLE_DOMAIN:-}",feedbackEndpoint:"${FEEDBACK_ENDPOINT:-}",errorEndpoint:"${ERROR_ENDPOINT:-}",supabaseUrl:"${SUPABASE_URL:-}",supabaseAnonKey:"${SUPABASE_ANON_KEY:-}"};
if(PSY_CONFIG.supabaseUrl&&PSY_CONFIG.supabaseAnonKey)window.PSY_CLOUD={url:PSY_CONFIG.supabaseUrl,key:PSY_CONFIG.supabaseAnonKey};
JS
for f in index.html sitemap.xml robots.txt; do sed -i "s#https://YOUR-DOMAIN#$SITE#g" "$f"; done

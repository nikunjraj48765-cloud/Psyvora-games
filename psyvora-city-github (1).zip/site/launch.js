/* Psyvora City launch layer: errors, offline, consent + analytics, feedback, accessibility, self-test */
(function(){
if(window.__noGL)return;
var C=window.PSY_CONFIG||{},$$=function(i){return document.getElementById(i)},esc=function(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})};
function lg(k){try{return localStorage.getItem(k)}catch(e){return null}}function ls(k,v){try{localStorage.setItem(k,v)}catch(e){}}
// ----- consent + privacy-friendly analytics (Plausible, loaded only after opt-in) -----
window.plausible=window.plausible||function(){(window.plausible.q=window.plausible.q||[]).push(arguments)};
function track(n,p){try{if(lg("psyconsent")=="all"&&C.plausibleDomain)window.plausible(n,p?{props:p}:undefined)}catch(e){}}
function loadAn(){if(!C.plausibleDomain||$$("p5an"))return;var s=document.createElement("script");s.id="p5an";s.defer=true;s.src=C.plausibleScript||"https://plausible.io/js/script.js";s.setAttribute("data-domain",C.plausibleDomain);document.head.appendChild(s)}
function consent(){if(lg("psyconsent"))return;var b=document.createElement("div");b.id="p5c";b.className="gls";b.setAttribute("role","region");b.setAttribute("aria-label","Privacy notice");b.innerHTML='<b>Your privacy</b><p>We use your browser’s storage to save progress. We set no tracking cookies. Optional anonymous analytics help us improve. <a href="privacy.html" target="_blank" rel="noopener">Privacy</a> · <a href="cookies.html" target="_blank" rel="noopener">Cookies</a></p><div><button class=pri id=p5y>Allow analytics</button> <button class=sec id=p5n>Essential only</button></div>';document.body.appendChild(b);
 $$("p5y").onclick=function(){ls("psyconsent","all");b.remove();loadAn();track("session_start")};$$("p5n").onclick=function(){ls("psyconsent","essential");b.remove()}}
if(lg("psyconsent")=="all"){loadAn();track("session_start")}
var t0=Date.now();addEventListener("pagehide",function(){track("play_time",{minutes:Math.round((Date.now()-t0)/6e4)})});
try{if(window.PsyPlatform)Object.keys(PsyPlatform.modules).forEach(function(k){var f=PsyPlatform.modules[k];PsyPlatform.modules[k]=function(){track("feature",{name:k});return f.apply(this,arguments)}});
 var _a=ach;ach=function(i,t){track("achievement",{name:String(t).slice(0,40)});return _a.apply(this,arguments)};if(typeof vtoggle=="function"){var _v=vtoggle;vtoggle=function(){track("vehicle_toggle");return _v.apply(this,arguments)}}}catch(e){}
document.addEventListener("click",function(e){var t=e.target.closest&&e.target.closest("[data-a]");if(t)track("click",{id:t.dataset.a})},true);
// ----- error handling: log, friendly panel, optional remote endpoint -----
var errs=[],burst=[];try{errs=JSON.parse(lg("psyerrlog"))||[]}catch(e){}
function showErr(){if($$("p5e"))return;var o=document.createElement("div");o.id="p5e";o.setAttribute("role","alertdialog");o.setAttribute("aria-label","Something went wrong");o.innerHTML='<div class=card><div style="font-size:42px">🌧️</div><h3>Something went wrong</h3><p class=sub>Your progress is saved automatically. You can reload the city or keep playing.</p><div class=p4r><button class=pri id=p5r>Reload</button><button class=sec id=p5k>Keep playing</button><button class=sec id=p5b>Report this</button></div></div>';document.body.appendChild(o);$$("p5r").onclick=function(){location.reload()};$$("p5k").onclick=function(){o.remove()};$$("p5b").onclick=function(){o.remove();openFb("bug")}}
function logErr(m,s,l){m=String(m||"");if(/ResizeObserver|^Script error\.?$/.test(m))return;var e={m:m.slice(0,200),s:String(s||"").slice(-60),l:l||0,t:Date.now()};errs.push(e);errs=errs.slice(-20);ls("psyerrlog",JSON.stringify(errs));
 try{if(C.errorEndpoint&&navigator.sendBeacon)navigator.sendBeacon(C.errorEndpoint,JSON.stringify({m:e.m,s:e.s,l:e.l,ua:navigator.userAgent,v:C.version||"beta"}))}catch(x){}
 var n=Date.now();burst=burst.filter(function(t){return t>n-1e4});burst.push(n);if(burst.length>=4)showErr()}
addEventListener("error",function(e){logErr(e.message,e.filename,e.lineno)});addEventListener("unhandledrejection",function(e){logErr(e.reason&&e.reason.message||e.reason,"promise")});
// ----- offline / connection -----
var ob=document.createElement("div");ob.id="p5o";ob.setAttribute("role","status");ob.hidden=true;document.body.appendChild(ob);var ot;
function net(){clearTimeout(ot);if(!navigator.onLine){ob.textContent="You’re offline. Your progress is saved on this device.";ob.hidden=false}else if(!ob.hidden){ob.textContent="Back online";ot=setTimeout(function(){ob.hidden=true},2200)}}
addEventListener("online",net);addEventListener("offline",net);net();
if("serviceWorker"in navigator&&(location.protocol=="https:"||location.hostname=="localhost"))addEventListener("load",function(){navigator.serviceWorker.register("sw.js").catch(function(){})});
// ----- feedback / bug / feature / support -----
var sent=0,TY={bug:["🐞 Bug","Describe what happened and what you expected."],feedback:["💬 Feedback","What’s working, and what could be better?"],feature:["💡 Feature","What would you like to see?"],support:["🛟 Support","How can we help?"]};
function openFb(tab){tab=TY[tab]?tab:"feedback";var m=$$("mb");$$("modal").hidden=false;
 m.innerHTML='<h3>Help and feedback</h3><div class=p4r>'+Object.keys(TY).map(function(k){return'<button class=chip data-f='+k+' aria-pressed='+(k==tab)+'>'+TY[k][0]+'</button>'}).join("")+'</div><p class=sub>'+TY[tab][1]+'</p><textarea class=p2n id=p5m rows=5 maxlength=1000 placeholder="At least 10 characters" aria-label="Your message" style="color:#000;background:#fff"></textarea><input class=p2n id=p5em type=email placeholder="Email (optional, if you want a reply)" maxlength=120 style="margin-top:8px"><input id=p5h tabindex=-1 autocomplete=off aria-hidden=true style="position:absolute;left:-9999px">'+(tab=="bug"?'<label style="font-size:13px;display:block;margin:8px 0"><input type=checkbox id=p5d checked> Attach technical details (recent error messages, browser)</label>':"")+'<div class=p4r><button class=pri id=p5s>Send</button></div><p class=sub id=p5st></p><p class=note>Not for emergencies. In crisis, call or text 988 (US), Tele-MANAS 14416 (India), or your local emergency number.</p><p class=note><a href="privacy.html" target=_blank rel=noopener>Privacy</a> · <a href="terms.html" target=_blank rel=noopener>Terms</a> · <a href="cookies.html" target=_blank rel=noopener>Cookies</a> · <a href="disclaimer.html" target=_blank rel=noopener>Disclaimer</a> · <a href="support.html" target=_blank rel=noopener>Contact</a></p>';
 m.onclick=function(e){var b=e.target.closest("[data-f]");if(b)openFb(b.dataset.f)};["p5m","p5em"].forEach(function(i){$$(i).onkeydown=function(e){e.stopPropagation()}});
 $$("p5s").onclick=function(){var st=$$("p5st"),msg=$$("p5m").value.trim(),em=$$("p5em").value.trim();if(msg.length<10){st.textContent="Please write at least 10 characters.";return}if(em&&!/^[^\s@<>"]+@[^\s@<>"]+\.[^\s@<>"]+$/.test(em)){st.textContent="That email doesn’t look right.";return}
  if($$("p5h").value){st.textContent="Thank you!";return}if(Date.now()-sent<3e4){st.textContent="Please wait a few seconds before sending another.";return}sent=Date.now();
  var p={type:tab,message:msg,email:em,url:location.href,ua:navigator.userAgent,v:C.version||"beta",ts:new Date().toISOString()};if($$("p5d")&&$$("p5d").checked)p.errors=errs.slice(-5);track("feedback_sent",{type:tab});
  var mail=function(){location.href="mailto:"+(C.supportEmail||"")+"?subject="+encodeURIComponent("[Psyvora "+tab+"] beta")+"&body="+encodeURIComponent((msg+"\n\n"+(em?"Reply to: "+em+"\n":"")+"Browser: "+navigator.userAgent).slice(0,1500))};
  if(!C.feedbackEndpoint){st.textContent="Opening your email app…";mail();return}
  st.textContent="Sending…";var n=0;(function go(){fetch(C.feedbackEndpoint,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(p)}).then(function(r){if(!r.ok)throw 0;st.textContent="Thank you! We read every message.";$$("p5m").value=""}).catch(function(){if(++n<3)setTimeout(go,1200*n);else{st.innerHTML="Couldn’t send. <a href=# id=p5ml>Send by email instead</a>";$$("p5ml").onclick=function(e){e.preventDefault();mail()}}})})()}};
// ----- accessibility: dialog semantics, focus trap, keyboard-operable controls, labels -----
var md=$$("modal"),last=null;
if(md){var sh=md.querySelector(".sheet");if(sh){sh.setAttribute("role","dialog");sh.setAttribute("aria-modal","true");sh.setAttribute("aria-label","Psyvora panel")}
 new MutationObserver(function(){if(!md.hidden){last=document.activeElement;setTimeout(function(){var f=md.querySelector("#mb button:not([disabled]),#mb input,#mb textarea,#mb select")||$$("x");if(f&&f.focus)f.focus()},60)}else if(last&&last.focus){last.focus();last=null}}).observe(md,{attributes:true,attributeFilter:["hidden"]});
 md.addEventListener("keydown",function(e){if(e.key!="Tab")return;var f=md.querySelectorAll("button:not([disabled]),input:not([tabindex='-1']),textarea,select,[tabindex='0']");if(!f.length)return;var a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement==a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement==z){e.preventDefault();a.focus()}});
 var mb=$$("mb");if(mb)new MutationObserver(function(){mb.querySelectorAll("[data-a]:not(button):not([tabindex])").forEach(function(n){n.setAttribute("tabindex","0");n.setAttribute("role","button");n.setAttribute("aria-label",n.getAttribute("aria-label")||"Choose "+(n.dataset.v||"option"))})}).observe(mb,{childList:true})}
document.addEventListener("keydown",function(e){var t=e.target;if((e.key=="Enter"||e.key==" ")&&t&&t.getAttribute&&t.getAttribute("role")=="button"&&t.tagName!="BUTTON"){e.preventDefault();t.click()}});
try{R.domElement.setAttribute("role","img");R.domElement.setAttribute("aria-label","Psyvora City, an interactive 3D city. Use the on-screen controls or keyboard to explore.")}catch(e){}
// ----- dock button -----
var dk=$$("p4d")||$$("hud");if(dk){var fb=document.createElement("button");fb.className="pill";fb.id="p5f";fb.setAttribute("aria-label","Help and feedback");fb.textContent="💬";fb.onclick=function(){openFb("feedback")};dk.appendChild(fb)}
setTimeout(consent,2500);
// ----- smoke test: PsyQA.run() in the browser console -----
window.PsyQA={run:function(){var r=[],ok=function(n,f){var v;try{v=f()}catch(e){v=false;n+=" ("+e.message+")"}r.push({check:n,pass:!!v})};
 ok("three.js loaded",function(){return window.THREE});ok("renderer canvas",function(){return R.domElement.isConnected});ok("HUD present",function(){return $$("hud")});ok("buildings registered",function(){return PL.length>=15});ok("game state",function(){return GS&&typeof GS.x=="number"});ok("storage writable",function(){localStorage.setItem("psyqa","1");localStorage.removeItem("psyqa");return 1});
 
 if(window.PsyPlatform)Object.keys(PsyPlatform.modules).forEach(function(k){ok("module "+k+" opens",function(){PsyPlatform.modules[k]();var good=!$$("modal").hidden&&$$("mb").innerHTML.length>40;$$("modal").hidden=true;return good})});
 ok("settings panels",function(){var b=$$("p2b4");b.click();var g=$$("mb").innerHTML.length>40;$$("modal").hidden=true;return g});
 ok("profile",function(){$$("p2b1").click();var g=$$("mb").innerHTML.length>40;$$("modal").hidden=true;return g});
 ok("missions",function(){$$("p2b2").click();var g=$$("mb").innerHTML.length>40;$$("modal").hidden=true;return g});
 ok("feedback form",function(){openFb("bug");var g=!!$$("p5s");$$("modal").hidden=true;return g});
 ok("no recent logged errors",function(){return errs.filter(function(e){return Date.now()-e.t<6e4}).length==0});
 console.table(r);var f=r.filter(function(x){return!x.pass}).length;console.log(f?f+" check(s) failed":"All "+r.length+" checks passed");return r}};
})();

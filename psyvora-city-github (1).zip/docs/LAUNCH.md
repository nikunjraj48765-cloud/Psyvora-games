# Psyvora City: launch package

Static site. No build step and no server code. Upload the folder contents to any static host.

## Deploy (5 minutes)
1. Edit `config.js` (or run `sh build.sh` with env vars: `SITE_URL`, `SUPPORT_EMAIL`, `PLAUSIBLE_DOMAIN`, `FEEDBACK_ENDPOINT`, `ERROR_ENDPOINT`, `SUPABASE_URL`, `SUPABASE_ANON_KEY`).
2. Replace `https://YOUR-DOMAIN` in `index.html`, `sitemap.xml`, `robots.txt` (build.sh does this from `SITE_URL`).
3. Fill the `[Company legal name]`, `[address]`, `[Jurisdiction]` placeholders in `terms.html`, `privacy.html`, `disclaimer.html`, and have a lawyer review the legal pages.
4. Deploy on **Netlify** (drag the folder; `_headers` is used) or **Vercel** (`vercel.json` is used). GitHub Pages ignores both header files, so the security headers would be missing there.
5. Serve over HTTPS (needed for the offline service worker). Gzip/Brotli is automatic on those hosts; `index.html` is about 134 KB gzipped.

## What each setting does
- `feedbackEndpoint`: any form backend that accepts JSON POSTs (Formspree, Basin, your own). Empty means the 💬 form opens the user's email app.
- `plausibleDomain`: switches on anonymous analytics (visitors, sessions, feature use, play time), loaded only after a visitor allows it.
- `errorEndpoint`: receives anonymous error reports via `sendBeacon`. Empty means errors are only kept on the device.
- `supabaseUrl` + `supabaseAnonKey`: lets the Therapist Directory and Summit Hall read your `therapists` and `workshops` tables. Needs public read RLS on those tables. The anon key is public by design; never put a service_role key anywhere in this folder.

## Security notes
- There are no accounts, so no passwords, sessions, cookies or server routes exist to attack. CSRF and SQL injection do not apply to a static page; the only database access is read-only REST through Supabase with RLS.
- All user text rendered with `innerHTML` is escaped, including database-supplied fields. Inputs are length-limited and validated; the feedback form has a honeypot and a 30-second send limit.
- Headers: CSP, HSTS, frame denial, nosniff, referrer and permissions policies. The CSP needs `'unsafe-inline'` because the game's code is inline. Moving it to external files would let you remove that.
- Journal, mood and chat data live in the player's browser only, so anyone using the same browser profile can read them.
- Rate abuse on feedback or error endpoints must be limited by the service you point them at.

## QA
Run `PsyQA.run()` in the browser console after the game loads. It checks the 3D engine, HUD, buildings, storage, every wellness module, settings, profile, missions and the feedback form, and prints a pass/fail table.

| Area | Status |
|---|---|
| All scripts parse; links between pages resolve; no auth code remains | Verified here |
| Gameplay, camera, vehicles, collisions, audio, mobile FPS, zero console errors | **Not tested** (no browser available when this was built); run `PsyQA.run()` and play through on desktop, phone and tablet |
| Lighthouse (performance, accessibility, SEO) | **Not run**; run it on the deployed URL and fix anything it flags |
| Texture compression, LOD, instancing | Not applicable or not done: the city is procedural, with no image assets, so there is nothing to compress |
| `og-image.png` | Simple generated placeholder; swap in branded artwork |

## Files
`index.html` the game · `config.js` settings · `launch.js` errors, offline banner, consent, analytics, feedback, accessibility, self-test · `sw.js` offline cache · `404/500/offline.html` · legal pages · `support.html` · SEO files · `_headers` / `vercel.json`

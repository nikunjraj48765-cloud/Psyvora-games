var V="psy-v1",PRE=["./","offline.html","config.js","launch.js","manifest.webmanifest","favicon.svg"];
self.addEventListener("install",function(e){e.waitUntil(caches.open(V).then(function(c){return c.addAll(PRE)}).then(function(){return self.skipWaiting()}))});
self.addEventListener("activate",function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return x!=V}).map(function(x){return caches.delete(x)}))}).then(function(){return self.clients.claim()}))});
self.addEventListener("fetch",function(e){var r=e.request;if(r.method!="GET")return;var u=new URL(r.url),cdn=/cdnjs\.cloudflare\.com|fonts\.(googleapis|gstatic)\.com/.test(u.host);if(u.origin!=location.origin&&!cdn)return;
 if(cdn){e.respondWith(caches.match(r).then(function(h){return h||fetch(r).then(function(x){var c=x.clone();caches.open(V).then(function(ca){ca.put(r,c)});return x})}));return}
 e.respondWith(fetch(r).then(function(x){var c=x.clone();caches.open(V).then(function(ca){ca.put(r,c)});return x}).catch(function(){return caches.match(r).then(function(h){return h||(r.mode=="navigate"?caches.match("offline.html"):Response.error())})}))});

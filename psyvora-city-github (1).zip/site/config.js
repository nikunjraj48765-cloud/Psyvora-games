/* Edit these, or generate this file in CI with build.sh. Everything here is PUBLIC: never put a Supabase service_role key here. */
window.PSY_CONFIG={siteUrl:"https://YOUR-DOMAIN",supportEmail:"support@YOUR-DOMAIN",version:"1.0.0-beta",plausibleDomain:"",feedbackEndpoint:"",errorEndpoint:"",supabaseUrl:"",supabaseAnonKey:""};
if(PSY_CONFIG.supabaseUrl&&PSY_CONFIG.supabaseAnonKey)window.PSY_CLOUD={url:PSY_CONFIG.supabaseUrl,key:PSY_CONFIG.supabaseAnonKey};
